import java.util.*; 
  
public class FloresElmer_324 { 

 

     
   public static int[] createArray (int arr[])
{
      
      int [] subOne= new int [10];
      int [] subTwo=new int[10];
      int counter=1;
           
      for(int i=0;i<arr.length;i++)
        {
           if(counter==1)
            subOne[i]=arr[i]; 
           if(counter==4)
            subOne[i]=arr[i]; 
            counter=counter+1;
           if(counter>4)
            {
            counter=1;
            }  
      
}
        
      System.out.println(Arrays.toString(subOne));
      return subOne;
}
     
     
   public static  int[] createArrayTwo (int arr[])
{
        int [] subTwo=new int[10];
        int counter=1;
        
         for(int i=0;i<arr.length;i++)
         {
            if(counter==2)
               subTwo[i]=arr[i]; 
            if(counter==3)
               subTwo[i]=arr[i]; 
        
         counter=counter+1;
            if(counter>4)
            {
            counter=1;
            }  
        
}
        
System.out.println(Arrays.toString(subTwo));
 return subTwo;
   }
  } 