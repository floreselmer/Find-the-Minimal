The first thing I did in my program was to set two varibles of the first and second set to zero.
My next step was to make the ADT list and I added the numbers one to ten.
I wanted to display the elements in the list so I added a for loop to print the elements.
I wasnt to familiar with a ADTList so I added all the elements for the list to an array and then two empty arrays for each subset.
I then went to make another file and there I made method that accepted the array that was made for the list.
In this method called createArray I made my first subarray and inserted  all the elements in index 1 and 4.I used a counter to have
the elements that I wanted. If the counter was greater than four it would reset. The reason why I wanted the elements that
had an index of 1 or 4 is because I realized that there was a pattern.For Example, if we have 4 elements like 1,2,3,4
elements 1 and 4 make 5 and elements 2 and 3 also make 5 , thus giving you the minimal result. One array gets the elements that are located 
in 1 and 4 because of the counter and the other method grabs the elements 2 and 3 from a counter.
I then return those sub arrays to main and then sum all the elements. Once i get the sum of the first and second array, all i have 
to do is subtract the largest array minus the smallest array to find the difference.