import java.util.ArrayList;
import java.util.*; 


public class FloresElmer_ListADT
 
{
    public static void main(String[] args)
    {
    int sumOne=0;
    int sumTwo=0;
    
      List<Integer> list = new ArrayList<Integer>(10);
      list.add(1);
      list.add(2);
      list.add(3);
      list.add(4);
      list.add(5);
      list.add(6);
      list.add(7);
      list.add(8);
      list.add(9);
      list.add(10);
      
         for (int i =0;i<list.size();i++) 
         { 
          System.out.print(list.get(i)+" "); 
         } 
        
     int arr[] = new int[list.size()]; 
     int n = arr.length; 
       
       
        for(int i = 0;i < arr.length;i++)
         arr[i] = list.get(i);
        
        System.out.println("");
        
         int []a ;
         int[]b;
         a=FloresElmer_324.createArray(arr);  
         b=FloresElmer_324.createArrayTwo(arr);
         
         for (int i : a)
         sumOne += i;
         for (int i : b)
         sumTwo += i;
         int total=sumTwo-sumOne;
         
         System.out.println("The sum of the first set is "+sumOne);
         System.out.println("The sum of the first set is "+sumTwo);
         System.out.println("The minimal is "+ total);
          
    }
}
